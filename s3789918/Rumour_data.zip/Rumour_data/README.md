# Determining Support for Rumours

**Licence  agreement:**   The  dataset  can  only  be  used  for  the  purpose  of  this  assignment. Sharing  or  distributing  this  data  or  using  this  data  for  any  other  commercial  or  non-commercial purposes is prohibited.

The dataset contains the following files:

- `twitter_dataset.csv`: Contains the data for the task of the assignment. You may segment the data into train/test/val and use each fold appropriately.
- `Extra_reddit_dataset.csv`: This is a set of extra data. You may use this data in developing you models. It is not mandatory to use this data.

##The columns of `twitter_dataset.csv`
- *Type*: Source or Reply
- *Msg_ID*: unique identifier for each tweet.
- *Source_ID*: id of the source massage. only relavent for a reply.
- *Text*: Massage text
- *Topic*: The subject of the tweet/massage.
- *class*: the target class. [comment, query, deny, support].  


